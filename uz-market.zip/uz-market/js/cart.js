document.addEventListener("DOMContentLoaded",()=>{
  const list=document.querySelector("#cart-items"),summary=document.querySelector("#cart-summary");if(!list||!summary)return;
  const money=window.formatMoney;
  function render(){
    const cart=getCart().filter(item=>getProduct(item.id));saveCart(cart);
    if(!cart.length){
      list.innerHTML='<div class="empty-cart"><div class="empty-cart-icon">🛍</div><h2>Savatchangiz hozircha bo‘sh</h2><p>Yoqtirgan mahsulotlaringizni tanlab, xaridni boshlang.</p><a class="btn btn-primary" href="catalog.html">Katalogni ko‘rish ↗</a></div>';
      summary.innerHTML='<h2>Buyurtma xulosasi</h2><p class="muted">Mahsulot qo‘shilgach, jami summa shu yerda ko‘rinadi.</p>';return;
    }
    list.innerHTML=cart.map(item=>{const p=getProduct(item.id);return `<article class="cart-item"><a href="product.html?id=${p.id}" class="cart-thumb"><img src="${p.image}" alt="${p.name}"></a><div class="cart-item-info"><span class="product-category">${p.category}</span><a class="cart-item-name" href="product.html?id=${p.id}">${p.name}</a><b>${money(p.price)}</b><button class="remove-item" data-remove="${p.id}">O‘chirish</button></div><div class="quantity-control"><button data-change="${p.id}" data-delta="-1" aria-label="Kamaytirish">−</button><span>${item.qty}</span><button data-change="${p.id}" data-delta="1" aria-label="Ko‘paytirish">+</button></div><b class="line-total">${money(p.price*item.qty)}</b></article>`}).join("");
    const subtotal=cart.reduce((sum,item)=>sum+getProduct(item.id).price*item.qty,0);const delivery=subtotal>=300000?0:25000;
    summary.innerHTML=`<h2>Buyurtma xulosasi</h2><div class="summary-line"><span>Mahsulotlar (${cart.reduce((s,i)=>s+i.qty,0)} ta)</span><b>${money(subtotal)}</b></div><div class="summary-line"><span>Yetkazib berish</span><b>${delivery?money(delivery):"Bepul"}</b></div><div class="summary-line total-line"><span>Jami</span><b>${money(subtotal+delivery)}</b></div><p class="summary-hint">${subtotal>=300000?"Siz bepul yetkazib berishga ega bo‘ldingiz!":"300 000 so‘mdan boshlab yetkazib berish bepul."}</p><a class="btn btn-primary btn-wide" href="checkout.html">Buyurtmani rasmiylashtirish →</a><a class="continue-link" href="catalog.html">← Xaridni davom ettirish</a>`;
  }
  list.addEventListener("click",e=>{
    const remove=e.target.closest("[data-remove]");const change=e.target.closest("[data-change]");
    if(remove){saveCart(getCart().filter(i=>i.id!==Number(remove.dataset.remove)));render();}
    if(change){const id=Number(change.dataset.change),delta=Number(change.dataset.delta),cart=getCart(),item=cart.find(i=>i.id===id);if(item){item.qty=Math.max(0,Math.min(20,item.qty+delta));saveCart(cart.filter(i=>i.qty>0));render();}}
  });
  window.addEventListener("storage",render);render();
});
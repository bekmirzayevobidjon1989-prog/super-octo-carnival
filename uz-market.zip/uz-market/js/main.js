(function(){
  const money = n => new Intl.NumberFormat("uz-UZ").format(n) + " so‘m";
  window.formatMoney = money;
  window.getProduct = id => (window.PRODUCTS || []).find(p => p.id === Number(id));
  window.getCart = () => { try { return JSON.parse(localStorage.getItem("uzmarket-cart") || "[]"); } catch(e) { return []; } };
  window.saveCart = cart => { localStorage.setItem("uzmarket-cart", JSON.stringify(cart)); updateCartBadges(); };
  window.updateCartBadges = function(){
    const count = getCart().reduce((sum,item)=>sum + item.qty,0);
    document.querySelectorAll(".cart-count").forEach(el=>el.textContent=count);
  };
  window.addToCart = function(id, qty=1){
    const p = getProduct(id); if(!p) return;
    const cart = getCart(); const item = cart.find(x=>x.id===p.id);
    if(item) item.qty += qty; else cart.push({id:p.id,qty:qty});
    saveCart(cart); showToast(p.name + " savatchaga qo‘shildi");
  };
  window.showToast = function(message){
    let toast=document.querySelector(".toast");
    if(!toast){toast=document.createElement("div");toast.className="toast";document.body.appendChild(toast);}
    toast.textContent=message; toast.classList.add("show");
    clearTimeout(window.toastTimer); window.toastTimer=setTimeout(()=>toast.classList.remove("show"),2600);
  };
  window.productCard = function(p){
    return `<article class="product-card">
      <a class="product-image" href="product.html?id=${p.id}">${p.tag?`<span class="product-tag">${p.tag}</span>`:""}<img loading="lazy" src="${p.image}" alt="${p.name}"><button class="quick-view" type="button" data-view="${p.id}" aria-label="Mahsulotni ko‘rish">↗</button></a>
      <div class="product-info"><span class="product-category">${p.category}</span><a href="product.html?id=${p.id}" class="product-name">${p.name}</a><div class="rating">★ <span>${p.rating}</span> <small>· Namuna reyting</small></div>
      <div class="price-row"><div><b class="price">${money(p.price)}</b>${p.oldPrice?`<del>${money(p.oldPrice)}</del>`:""}</div><button class="add-button" type="button" data-add="${p.id}" aria-label="Savatchaga qo‘shish">+</button></div></div>
    </article>`;
  };
  function renderCards(target, products){ const el=document.querySelector(target); if(el) el.innerHTML=products.map(productCard).join(""); }
  document.addEventListener("click",e=>{
    const add=e.target.closest("[data-add]"); if(add){e.preventDefault();addToCart(add.dataset.add);add.classList.add("added");setTimeout(()=>add.classList.remove("added"),500);}
    const view=e.target.closest("[data-view]"); if(view){e.preventDefault();location.href="product.html?id="+view.dataset.view;}
  });
  document.querySelectorAll("[data-search-form]").forEach(form=>form.addEventListener("submit",e=>{
    e.preventDefault(); const q=new FormData(form).get("q").trim(); location.href="catalog.html"+(q?"?q="+encodeURIComponent(q):"");
  }));
  function initCatalog(){
    const grid=document.querySelector("#catalog-products"); if(!grid)return;
    const category=document.querySelector("#category-filter"), sort=document.querySelector("#sort-filter"), price=document.querySelector("#price-filter");
    [...new Set(PRODUCTS.map(p=>p.category))].forEach(c=>category.add(new Option(c,c)));
    const params=new URLSearchParams(location.search); const q=(params.get("q")||"").toLowerCase(); const cat=params.get("category")||"";
    if(cat) category.value=cat;
    const searchInput=document.querySelector('[data-search-form] input'); if(searchInput)searchInput.value=params.get("q")||"";
    function update(){
      let items=PRODUCTS.filter(p=>(!category.value||p.category===category.value)&&(!q||(p.name+" "+p.description+" "+p.category).toLowerCase().includes(q))&&(price.value==="all"||p.price<=Number(price.value)));
      if(sort.value==="price-asc")items.sort((a,b)=>a.price-b.price);
      if(sort.value==="price-desc")items.sort((a,b)=>b.price-a.price);
      if(sort.value==="name")items.sort((a,b)=>a.name.localeCompare(b.name,"uz"));
      grid.innerHTML=items.map(productCard).join("");
      document.querySelector("#result-count").textContent=items.length+" ta mahsulot";
      document.querySelector("#no-results").classList.toggle("hidden",items.length>0);
    }
    [category,sort,price].forEach(el=>el.addEventListener("change",update));
    document.querySelector("#reset-filters").addEventListener("click",()=>{category.value="";sort.value="featured";price.value="all";update();});
    update();
  }
  function initHome(){renderCards("#featured-products",PRODUCTS.slice(0,4));}
  function initProduct(){
    const root=document.querySelector("#product-detail");if(!root)return;
    const id=new URLSearchParams(location.search).get("id")||"1";const p=getProduct(id);
    if(!p){root.innerHTML='<div class="empty-state"><h2>Mahsulot topilmadi</h2><a class="btn btn-primary" href="catalog.html">Katalogga qaytish</a></div>';return;}
    root.innerHTML=`<div class="detail-image"><img src="${p.image}" alt="${p.name}"></div><div class="detail-copy"><span class="eyebrow">${p.category}</span><h1>${p.name}</h1><div class="rating">★ ${p.rating} <small>· Namuna reyting</small></div><div class="detail-price">${money(p.price)} ${p.oldPrice?`<del>${money(p.oldPrice)}</del>`:""}</div><p>${p.description}</p><div class="detail-meta"><span>✓ Mavjudligi: namuna ombor</span><span>✓ Qulay xarid</span><span>✓ Yetkazib berish checkout’da hisoblanadi</span></div><label class="qty-label">Miqdor <input type="number" id="detail-qty" value="1" min="1" max="20"></label><div class="detail-actions"><button class="btn btn-primary" id="detail-add">Savatchaga qo‘shish <span>＋</span></button><a class="btn btn-light" href="cart.html">Savatchaga o‘tish</a></div><div class="notice">Mahsulot tavsifi va narxi namuna uchun kiritilgan.</div></div>`;
    document.querySelector("#detail-add").addEventListener("click",()=>{const qty=Math.max(1,Math.min(20,Number(document.querySelector("#detail-qty").value)||1));addToCart(p.id,qty);});
    renderCards("#related-products",PRODUCTS.filter(x=>x.id!==p.id).slice(0,4));
  }
  document.addEventListener("DOMContentLoaded",()=>{updateCartBadges();initHome();initCatalog();initProduct();});
})();
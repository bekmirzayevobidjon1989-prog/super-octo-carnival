document.addEventListener("DOMContentLoaded",()=>{
  const form=document.querySelector("#checkout-form");if(!form)return;
  const summary=document.querySelector("#checkout-summary"),message=document.querySelector("#checkout-message");
  const money=window.formatMoney;
  function renderSummary(){
    const cart=getCart().filter(i=>getProduct(i.id));
    if(!cart.length){summary.innerHTML='<h2>Savatcha bo‘sh</h2><p class="muted">Avval katalogdan mahsulot tanlang.</p><a class="btn btn-primary btn-wide" href="catalog.html">Katalogga o‘tish</a>';form.querySelector('button[type="submit"]').disabled=true;return;}
    form.querySelector('button[type="submit"]').disabled=false;
    const subtotal=cart.reduce((s,i)=>s+getProduct(i.id).price*i.qty,0),delivery=subtotal>=300000?0:25000;
    summary.innerHTML=`<h2>Buyurtmangiz</h2>${cart.map(i=>{const p=getProduct(i.id);return `<div class="checkout-product"><img src="${p.image}" alt=""><div><b>${p.name}</b><small>${i.qty} dona</small></div><strong>${money(p.price*i.qty)}</strong></div>`}).join("")}<div class="summary-line"><span>Mahsulotlar</span><b>${money(subtotal)}</b></div><div class="summary-line"><span>Yetkazib berish</span><b>${delivery?money(delivery):"Bepul"}</b></div><div class="summary-line total-line"><span>Jami</span><b>${money(subtotal+delivery)}</b></div>`;
  }
  form.addEventListener("submit",e=>{
    e.preventDefault();if(!form.reportValidity())return;
    const cart=getCart();if(!cart.length){showToast("Savatcha bo‘sh");return;}
    const data=Object.fromEntries(new FormData(form).entries());
    const order={id:"DEMO-"+Date.now().toString().slice(-8),createdAt:new Date().toISOString(),customer:{fullName:data.fullName,phone:data.phone,address:data.address,city:data.city,note:data.note},paymentMethod:data.payment,status:"DEMO — to‘lov amalga oshirilmagan",items:cart};
    const orders=JSON.parse(localStorage.getItem("uzmarket-demo-orders")||"[]");orders.push(order);localStorage.setItem("uzmarket-demo-orders",JSON.stringify(orders));
    message.classList.remove("hidden");message.innerHTML=`<div class="success-icon">✓</div><h2>Demo buyurtma yaratildi!</h2><p>Buyurtma raqami: <b>${order.id}</b></p><p>Bu sinov rejimi. <b>Hech qanday pul yechilmadi</b> va to‘lov amalga oshmadi. Real to‘lov uchun Payme/Click server integratsiyasini sozlash kerak.</p><a class="btn btn-primary" href="index.html">Bosh sahifaga qaytish</a>`;
    localStorage.removeItem("uzmarket-cart");updateCartBadges();form.classList.add("hidden");summary.classList.add("hidden");message.scrollIntoView({behavior:"smooth",block:"center"});
  });
  renderSummary();
});
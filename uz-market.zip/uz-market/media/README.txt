Ixtiyoriy media fayllarini shu papkaga joylang:
- showcase.mp4 (bosh sahifa videosi)
- music.mp3 (audio player uchun musiqa)
Faqat foydalanishga ruxsat berilgan fayllardan foydalaning.

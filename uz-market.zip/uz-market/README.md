# UZ Market (HTML + CSS + Vanilla JavaScript)

## Ishga tushirish
1. `uz-market` papkasini VS Code'da oching.
2. VS Code'da Live Server extensionini o'rnating.
3. `index.html` ustida o'ng tugma -> **Open with Live Server**.
4. Katalog, mahsulot, savatcha va checkout sahifalarini tekshiring.

## Fayllar
- `index.html` — bosh sahifa
- `catalog.html` — katalog, qidiruv va filtrlar
- `product.html` — mahsulot tafsilotlari (`?id=1` kabi)
- `cart.html` — savatcha
- `checkout.html` — buyurtma formasi (demo rejim)
- `css/style.css` — dizayn, responsive va animatsiyalar
- `js/products.js` — mahsulot ma'lumotlari
- `js/main.js` — umumiy funksiyalar
- `js/cart.js` — savatcha
- `js/checkout.js` — demo buyurtma

## Muhim
- Mahsulot narxlari va reytinglari namuna ma'lumotlari.
- Rasmlar internetdan yuklanadi, internet aloqasi kerak.
- `media/showcase.mp4` va `media/music.mp3` uchun o'zingiz foydalanish huquqiga ega media fayllarni qo'ying.
- Checkout hozircha DEMO. U real to'lov olmaydi. Haqiqiy Payme/Click to'lovi uchun server, merchant credentials, provayder API va webhook tekshiruvi kerak.
- `localStorage` faqat shu brauzer/qurilmada saqlaydi; haqiqiy buyurtmalar serverda saqlanishi kerak.
